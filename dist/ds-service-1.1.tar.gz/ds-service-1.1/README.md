# ds_service

Service exytracts text from the sms and coverts to a meaningful json using an LLM via Langchain.